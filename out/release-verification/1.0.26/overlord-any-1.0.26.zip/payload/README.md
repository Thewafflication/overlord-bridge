# Overlord Bridge

Telegram's native command menu is registered for the owner chat on startup.
Send `/menu` or `/start` to open a button panel with status, all-engine status,
model and effort selection, brain options, permission grants, pending questions,
work status, and Stop Turn. The Session page offers token usage, context,
compaction, and a new session; the last two require a confirmation tap.
Navigation edits the same panel, and actions use the existing command handlers.
Menu setup failures are logged without preventing polling. Restart the bridge
after upgrading to register the command menu.

Drive a home-rooted **"Overlord"** from Telegram on your phone. The Overlord's
**brain is swappable**: Claude (the Claude Agent SDK, the default) or OpenAI
Codex (the `codex app-server`), selected with one env flag.

The Overlord runs in `/home/user`, so it can dispatch agents into any
`~/Projects/*` or `~/Documents/*` folder. Any action that isn't pre-approved is
bounced to your phone as an **Allow once / Deny / This exact action (session)**
prompt, and an
off-limits backstop auto-denies obvious secrets — both apply regardless of
which brain is active.

It's a slimmed-down descendant of the `Joshua` assistant: same threaded
`python-telegram-bot` handler + queue pump, with a pluggable brain behind a
common interface and a remote permission gate added.

## Files

| File | Purpose |
|------|---------|
| `bridge.py` | Main loop: queue pump → `Brain` → streamed replies; selects the brain from `OVERLORD_BRAIN` |
| `modules/brain.py` | `Brain` ABC + shared `PermissionGate` (off-limits backstop + Telegram approval choices + timeout) |
| `modules/claude_brain.py` | `ClaudeBrain`: the Claude Agent SDK behind the interface |
| `modules/codex_brain.py` | `CodexBrain`: the Codex App Server (JSON-RPC over stdio or WebSocket) behind the interface |
| `modules/version.py` | Single version source: package metadata → `pyproject.toml` → fallback, plus the short git revision read straight out of `.git` (no subprocess) |
| `modules/token_meter.py` | Per-prompt token ledger: normalizes both brains' usage shapes, persists a bounded history, renders the footer / `/tokens` / `/status` blocks, and estimates tokens locally for `/quote` |
| `modules/telegram_handler.py` | Threaded Telegram I/O (owner-gated, chunked, three-choice permission buttons) |
| `modules/workers.py` | Dispatch-folder worker runner for Claude, Codex, and local-agent workers; Telegram completion push; worker report audit store |
| `modules/fetch_relay.py` | Localhost-only headless-Chromium fetch endpoint (`GET /fetch?url=`) for sites that domain-block WebFetch or bot-wall curl; standalone process, own service |
| `AGENTS.example.md` | Sanitized template of the canonical shared Overlord instruction file (role, dispatch rules, off-limits). Copy to `AGENTS.md`, edit for your machine, then symlink it as `~/.claude/CLAUDE.md` + `~/AGENTS.md` so Claude and Codex share one file. (Your real `AGENTS.md` stays local — it's gitignored.) |
| `overlord-bridge.service` | `systemd --user` unit |
| `overlord-fetch-relay.service` | `systemd --user` unit for `modules/fetch_relay.py` |
| `.env.example` | Config template |

## Choosing the brain

Set `OVERLORD_BRAIN` in `.env`:

- `OVERLORD_BRAIN=claude` *(default)* — the live, deployed behavior. Loads
  `~/.claude/CLAUDE.md` + `~/.claude/settings.json` deny rules as a hard floor.
- `OVERLORD_BRAIN=codex` — uses the Codex CLI's `app-server`. See
  [Codex setup](#codex-brain-setup) below.

Both brains share the same Telegram I/O, the `.session` persistence file, the
`/new` reset, and the `PermissionGate` (off-limits auto-deny + approval choices +
timeout). Switching brains is just changing the flag and restarting the service.

## Setup

1. **Create a bot.** In Telegram, message [@BotFather](https://t.me/BotFather)
   → `/newbot` → copy the token. Use a *new* bot, separate from Joshua.
2. **Get your chat id.** Message [@userinfobot](https://t.me/userinfobot); it
   replies with your numeric id.
3. **Configure.**
   ```bash
   cd ~/Projects/overlord-bridge
   cp .env.example .env
   $EDITOR .env          # paste TELEGRAM_BOT_TOKEN and OWNER_CHAT_ID
   chmod 600 .env
   ```
4. **Dependencies** are already installed in `.venv`. To recreate:
   ```bash
   python3 -m venv .venv && .venv/bin/pip install -r requirements.txt
   ```

## Run

Foreground (for a first test):
```bash
.venv/bin/python bridge.py
```
You should get a `🟢 Overlord v0.1.0+2576523 online` message in Telegram. Send it
a task.

The version comes from `modules/version.py`, which resolves it once from
`pyproject.toml`, then installed package metadata, then a hardcoded fallback, and
appends the short git revision when running from a checkout. Bump
`pyproject.toml` and nothing else — pyproject deliberately outranks the installed
metadata, because an editable install's `overlord_bridge.egg-info` is only as
fresh as the last `pip install -e .`. It appears in the
startup message, every `/status` reply, the tray tooltip and menu, and the
console title bar — so a screenshot of any of them identifies the build.

Telegram commands:

- `/help` lists the available commands.
- `/status` shows the active brain, resolved model, reasoning effort, session
  state, this conversation's token tally, and the usage-limit windows — without
  consuming a model turn. Each `/status` takes a **live** reading first and only
  falls back to the last one if the provider does not answer within
  `OVERLORD_STATUS_REFRESH_TIMEOUT` (8s), and the reply always prints how old
  the reading is. A background loop keeps the tray and console current every
  `OVERLORD_STATUS_REFRESH_SECS` (60s).
- `/status all` shows every brain side by side, active one first. Only the
  active brain can be read live — asking a standby Codex for its rate limits
  would mean spawning its app-server — so the others are rendered from their
  last cached usage and configured settings, and labelled `STANDBY`.
- `/tokens [n]` lists the last *n* prompts (default 10) with input, output and
  total tokens each, plus the session totals. The ledger is kept in
  `run/token_ledger.json`, so it survives a restart; `/new` clears it.
- `/quote <text>` prices a prompt *before* you send it. Claude counts it exactly
  via Anthropic's `count_tokens` endpoint (free, and it never touches the pinned
  session); if that is unavailable — offline, no credentials, Codex active — it
  falls back to a local estimate and says so. Anything queued to ride along with
  your next turn, such as a pending brain-switch handoff, is quoted too.
- `/model [name]` shows or changes the active brain's model, and `/effort
  [level]` does the same for reasoning effort (Claude: low/medium/high/xhigh/max;
  Codex: minimal/low/medium/high). Both take effect on your next message and are
  persisted to `.env` under that brain's own key, so changing Claude's model
  never disturbs Codex's. Claude applies them without reconnecting; Codex
  re-opens the *same* thread so the conversation survives the change.
- `/stop` interrupts the active AI turn.
- `/steer <message>` interrupts the active turn and starts the replacement
  guidance after the engine has cleaned up.
- `/brain` shows the current brain; `/brain claude` and `/brain codex` switch
  immediately and persist the selection for the next restart. Recent Telegram
  conversation is handed to the newly selected brain with the next real user
  message, bounded by `OVERLORD_HANDOFF_CONTEXT_CHARS` (default 12,000).
- `/new` starts a clean conversation and resets the token tally.
- `/context` shows retained messages, checkpoint status, and recovery warnings.
  Bounded cross-brain history is saved atomically under `run/conversation.json`
  and restored on restart. A damaged primary can recover the previous snapshot.
  Checkpoints are bound to the configured workspace; `/new` clears both copies.
  Provider context pressure is labelled unknown when it cannot be measured.
- `/compact` saves a recovery checkpoint and runs native compaction while idle.
  Claude discovers its available command and requires a `compact_boundary`;
  Codex waits for its `contextCompaction` item and compaction turn to finish.
  A timeout reports unknown completion. Codex blocks new work until its pending
  compaction settles. Usage is recorded separately when reported by the provider.
  The Claude shared-terminal path still needs a separate native control transport;
  this command currently refuses that path without replacing its session.

Every reply is followed by a one-line token footer (`🧮 in … · out … · total …`)
with the running session total. Set `OVERLORD_TOKEN_FOOTER=false` to suppress the
line — `/status` and `/tokens` keep accounting either way. Cache *reads* are
reported separately from fresh input, so a long resumed session does not look
like it re-sends its whole history at full price every turn. A turn Claude hands
to a live terminal session reports no usage of its own and is skipped rather than
booked as a zero.

Turns that end badly are still accounted for. `/stop` and `/steer` cancel the
turn mid-flight, so the footer reports whatever the engine had streamed by then
and marks it `stopped mid-turn — partial count`; a failed turn, including
hitting a usage cap, is marked `turn failed`. Both count toward the session
total, and `/tokens` says how many of the listed prompts were cut short. For
Claude the partial figure is a running sum of the turn's assistant messages,
replaced by the authoritative total whenever the turn reaches its end.

When Claude or Codex needs a short clarification or offers several discrete
paths, Overlord asks it to use its native interactive-input tool. Telegram then
shows one button per option, including the model's descriptions, plus
**Type another answer**. Multi-question requests are shown sequentially, and a
typed reply supplies a custom answer after selecting **Type another answer**,
or when replying directly to the question message. Unrelated messages remain
ordinary conversation. `/questions` lists the pending ID; `/reply <id> <answer>`
answers it and `/cancelquestion <id>` cancels it. Secret-input requests are never
forwarded to Telegram.

As a managed service:
```bash
cp overlord-bridge.service ~/.config/systemd/user/
systemctl --user daemon-reload
systemctl --user enable --now overlord-bridge
systemctl --user status overlord-bridge
journalctl --user -u overlord-bridge -f      # logs
```

### Windows (native PowerShell)

The Telegram bridge and the private Codex app-server transport run natively on
Windows. The shared Unix-socket/tmux terminal mode and Claude background-job PTY
attachment remain Linux-only; leave `OVERLORD_CODEX_APP_SERVER_PROXY=false`.

From PowerShell:

```powershell
.\run-windows.ps1 -Install
notepad .env
.\run-windows.ps1
```

The first command creates `.venv`, installs the pinned dependencies, and creates
`.env` from `.env.example` when needed. In `.env`, fill in
`TELEGRAM_BOT_TOKEN` and `OWNER_CHAT_ID`, then add or uncomment:

```ini
OVERLORD_BRAIN=codex
OVERLORD_CODEX_APP_SERVER_PROXY=false
```

The launcher uses the directory from which you invoke it as the Codex workspace
unless `OVERLORD_CWD` or `-WorkingDirectory` specifies another directory. It
also discovers the native `codex.exe` bundled with Codex Desktop when ordinary
PowerShell does not have `codex` on `PATH`. The resolved absolute path is shared
with runtime brain switching and Codex workers even when Claude starts first.
To validate without starting:

```powershell
..\overlord-bridge\run-windows.ps1 -Check
```

For a writable project workspace, set
`OVERLORD_CODEX_SANDBOX=workspace-write` in `.env`. Use `-Help` or `/?` for the
launcher options.

While running on Windows, Overlord places an icon in the notification area.
Right-click it and choose the dynamic **Show Console** / **Hide Console** entry
to toggle a dedicated Tk rich-text console, or **Stop Overlord** for a graceful
shutdown. The console has a Status button row — **Refresh**, **Refresh All**,
**Send to Telegram**, **Send All to Telegram** — that reaches the running bridge
by writing `run/console-command.json`, which the bridge watches. It is one-way
and file-based on purpose: no socket to secure, and every action is read-only
with respect to the conversation, so a stale or unexpected file can never do
anything destructive. Launched without a bridge, the buttons are disabled rather
than silently doing nothing.

The console has Claude and Codex status cards, colored log levels,
live updates, Copy All, Clear, and Autoscroll controls over a rotating 2 MB log.
Choose **Settings…** in the console or tray to configure API keys, individual
project folders, folders containing projects, bridge auto-approval, Claude
workspace edit approval, and free-worker approval (`all`, `commands`, `none`).
Save applies the project list and bridge approval settings to the running
bridge. Individual projects appear by folder name in `/work`; parent folders
contribute their children. Explicit projects take precedence over discovered
projects with the same name. The workspace and standard project roots remain
available independently of this list. Native engine sandbox and permission
rules still apply, and off-limits folders cannot be registered.

Model shell activity is highlighted in green in the console: Codex command
start/completion events, Claude SDK Bash hooks, shared Claude Telegram-turn
transcript events, and free/local/NVIDIA worker
shell execution. Entries show the command, working folder, and completion
status (including exit code for Codex and worker executions). Loaded API keys
and tokens are redacted, multiline commands stay in one entry, and the existing
bounded rotating log retains the activity.
During AI turns, Telegram continuously shows the typing indicator; transient
Telegram send failures are retried automatically so replies, model questions,
and permission prompts are not dropped after a single network hiccup.

Overlord also holds an operating-system singleton lock. Starting a second copy
on the same machine user session exits immediately with a clear error instead
of creating competing Telegram pollers. The OS releases the lock automatically
if Overlord crashes or is forcibly terminated.

To install a general per-user Start Menu launcher, run:

```powershell
.\Install-WindowsLauncher.ps1
```

By default it launches Overlord at the parent folder containing this repository
(for example `C:\Users\you\source\repos`), installs the Overlord icon, creates a
canonical `AGENTS.md` there when one does not already exist, and configures both
brains to receive it explicitly. It also enables automatic approval for Claude
Edit/Write tools only when every target remains inside that projects root and
outside the hard off-limits list. Use `-ProjectsRoot PATH` to choose a different
root or `-Uninstall` to remove only the Start Menu shortcut.

The installer also adds the Claude Agent SDK's bundled `claude.exe` directory
to the current user's `PATH` (without duplicating an existing entry). Open a new
PowerShell window afterward to run periodic authentication commands such as
`claude auth login`. To configure only this PATH entry, without requiring a
configured bridge `.env`, run
`./Install-WindowsLauncher.ps1 -ClaudePathOnly`.

Install and authenticate Codex first if `codex --version` or `codex login` has
not already been run. Keep the PowerShell window open while testing. For an
always-on native Windows install, run this same script through Task Scheduler;
the included `.service` files are for Linux systemd only.

To keep it running while you're logged out (true "away from terminal"):
```bash
sudo loginctl enable-linger $USER
```

## Shared context: Telegram ⇄ terminal

The Overlord is **one conversation**, reachable from your phone *and* your
terminal — what you do "while mobile" is there when you sit down, and vice versa.

Both sides pin to the active brain's saved id (`.session.claude` or
`.session.codex`; cwd `/home/user`, so Claude sessions live in the normal
`~/.claude/projects/-home-user/` store):

- **Terminal:** run `overlord` (symlinked onto your PATH → `overlord-bridge/overlord`).
  It resumes the shared per-brain session so the terminal sees your Telegram
  history; if no session exists yet it mints one and records it so Telegram
  joins *that*.
  When the active brain is Codex and `OVERLORD_CODEX_APP_SERVER_PROXY=true`,
  the bridge and terminal attach to the same local app-server Unix socket. The
  env name is historical: the bridge starts `codex app-server --listen
  unix://PATH` and talks direct WebSocket to it, while the launcher resumes the
  pinned thread with `codex --remote unix://PATH resume <thread>`. Bridge-started
  Codex turns then use the same transport as the TUI instead of a private stdio
  app-server.
  It also mirrors Ben's shell `codex()` wrapper: if Kitty graphics are supported
  but not advertised via environment, it sets `KITTY_WINDOW_ID=1` before
  `codex`/`codex resume` so terminal pets and images render correctly.
- **Telegram:** before each reply the bridge checks whether the session's
  transcript changed on disk (a terminal turn) and reloads it, so your phone
  reflects terminal work too. (`ClaudeBrain._maybe_refresh`.)
- `/new` on either side resets the shared thread.

This works for **both brains** — the terminal `overlord` launcher reads
`OVERLORD_BRAIN` and resumes the matching pinned id:

| Brain | Pinned id file | Terminal resume | Bridge reload watches |
|-------|----------------|-----------------|------------------------|
| claude | `.session.claude` | `claude --resume <id>` | `~/.claude/projects/-home-user/<id>.jsonl` mtime |
| codex  | `.session.codex`  | `codex resume <id>`    | `~/.codex/sessions/**/rollout-*-<id>.jsonl` mtime |

Each brain keeps its **own** pinned thread, so switching brains doesn't mix a
Claude session id with a Codex thread id.

Caveat: drive one side at a time. They share a single transcript file, so typing
into the terminal and the phone *simultaneously* on the same session can interleave
writes. Hand off, don't co-pilot.

> Codex note: terminal Codex can't pin a brand-new id, so to link the two, send
> the bridge a message first (it creates + records the thread), then run `overlord`.

## Lazy-loaded capability tools

The repo includes a local Codex plugin at `plugins/overlord` so canonical
Overlord capabilities are exposed as searchable MCP tools instead of only prose
in `CAPABILITIES.md`. The repo-local marketplace lives at
`.agents/plugins/marketplace.json`.

Install or refresh the plugin:

```bash
codex plugin marketplace add /home/user/Projects/overlord-bridge
codex plugin add overlord@personal
```

The plugin currently exposes:

- `list_overlord_capabilities`
- `find_overlord_capabilities`
- `overlord_status`
- `send_overlord_email`
- `dispatch_overlord_worker`

Start a new Codex thread after installing or changing the plugin; existing
threads may not refresh lazy-loaded tool metadata.

### Companion plugins (separate projects)

The Overlord also drives two other plugins that live in their **own separate
repos**, not this one:

- **`voice-gateway`** — supervised AI phone calls through a PC-as-Bluetooth
  gateway (local Whisper STT, TTS, automatic DTMF).
- **`ytmusic-dj`** — an AI DJ for YouTube Music that resolves seed
  playlists/tracks to real videoIds and builds playlists.

They register with the bridge exactly like `overlord` does, but their source
isn't included here. **We may fold these projects into the repo (or publish them
alongside it) in the future.**

## Codex brain setup

To run the Overlord on OpenAI Codex instead of Claude:

1. **Install the Codex CLI** (not bundled here):
   ```bash
   npm i -g @openai/codex
   codex --version          # confirm it's on PATH
   ```
2. **Authenticate** — `codex app-server` reuses your Codex login:
   ```bash
   codex login              # ChatGPT or API-key auth; writes ~/.codex/auth.json
   ```
   The bridge fails with a clear error if the binary is missing; usage-limit /
   auth errors from Codex are relayed to your phone as `⚠️ …`.
3. **Flip the flag** in `.env`:
   ```ini
   OVERLORD_BRAIN=codex
   # optional, see .env.example for all knobs:
   # OVERLORD_CODEX_SANDBOX=read-only
   # OVERLORD_CODEX_APPROVAL_POLICY=on-request
   # OVERLORD_CODEX_MODEL=          # empty = codex default
   # OVERLORD_CODEX_BIN=codex
   # OVERLORD_CODEX_APP_SERVER_PROXY=false
   # OVERLORD_CODEX_APP_SERVER_SOCKET=/home/user/Projects/overlord-bridge/run/codex-app-server.sock
   # OVERLORD_CODEX_INSTRUCTIONS_FILE=~/Projects/overlord-bridge/AGENTS.md
   ```
4. **Restart** the service (or the foreground process):
   ```bash
   systemctl --user restart overlord-bridge
   ```

### Guardrails for Codex

Codex does **not** read `~/.claude/CLAUDE.md` or `~/.claude/settings.json`, so its
guardrails come from three places:

- **`AGENTS.md`** in this folder is the canonical shared Overlord instruction
  file, including the worker roster and dispatch-file protocol. Keep Claude and
  Codex pointed at this same file:
  ```bash
  ln -s ~/Projects/overlord-bridge/AGENTS.md ~/AGENTS.md
  ln -s ~/Projects/overlord-bridge/AGENTS.md ~/CLAUDE.md
  ln -s ~/Projects/overlord-bridge/AGENTS.md ~/.claude/CLAUDE.md
  ```
  The bridge also injects it into Codex app-server as `developerInstructions`
  on both `thread/start` and `thread/resume`, because the Overlord cwd is
  `/home/user` and Codex would not otherwise discover this repo's `AGENTS.md`.
- **Sandbox + approval policy** — set via `OVERLORD_CODEX_SANDBOX` (default
  `read-only`) and `OVERLORD_CODEX_APPROVAL_POLICY` (default `on-request`),
  passed to `thread/start` / `thread/resume`. The Overlord is rooted at
  `/home/user`, so read-only is the conservative default; write actions, such as
  dropping worker dispatch files, become permission prompts on your phone.
- **`PermissionGate`** (shared with the Claude path) auto-denies off-limits
  paths/commands and routes everything else to the phone, timing out into a deny.

> Note: this does not write Codex's global config under `~/.codex`. If you want a
> persistent sandbox/approval default at the Codex level, configure
> `~/.codex/config.toml` yourself; the bridge sets these per-thread.

### How the Codex approval round-trip works

`codex app-server` speaks JSON-RPC 2.0 over stdio for the private bridge mode,
or over WebSocket when the shared Unix-socket mode is enabled. When the agent
needs approval it sends a **server-initiated request** that pauses the turn
until the bridge replies. The bridge maps that onto the same Telegram permission
mechanism the Claude path uses:

| Codex server request | Telegram tap | Reply sent to Codex |
|----------------------|--------------|---------------------|
| `item/commandExecution/requestApproval` | ✅ Allow | `{ "decision": "accept" }` |
| `item/fileChange/requestApproval` | ⛔ Deny | `{ "decision": "decline" }` |
| (either) | no tap before `OVERLORD_PERMISSION_TIMEOUT` | auto-deny (off-limits) / declined |

Session resume uses the App Server's native threads: the `.session` file holds
the Codex `threadId`, replayed via `thread/resume` on startup (stale ids fall
back to a fresh `thread/start`). `/new` wipes it and starts a new thread.

## Worker Reports

Workers are dispatched by dropping JSON into `dispatch/`. When a worker finishes,
fails, times out, cannot start, or crashes, the bridge still sends the terminal
status to Telegram on its own. It also records bounded audit data locally:

- `worker_reports/events.jsonl` appends accepted/started/terminal events and
  rotates to `events.1.jsonl` after `WORKER_REPORT_EVENTS_MAX_BYTES`.
- `worker_reports/latest/<worker>.json` stores the latest event for quick
  standups.

Reports include the worker name, folder, brain, session, status, timestamps,
duration, exit code, result tail, and real Codex session id when the worker
prints one. The bridge does not store the original task text, caps tails, and
redacts common token/password forms.

Supported worker brains:

- `claude`: cloud Claude CLI worker, resumable via Claude session id.
- `codex`: cloud Codex CLI worker, resumable via Codex session id and optional
  per-dispatch `approval_policy` / `sandbox`.
- `local-agent`: local model agent worker, currently one-shot. Use this when the
  local model should behave like a small Codex/Claude-style agent: it can list
  files, read/write project files, run shell commands in the worker folder, see
  tool results, loop, validate, and commit. `files` is optional and only provides
  starting hints; the agent can inspect the project one file at a time. The first
  proven backend is `qwen3-coder-next` through on-demand `llama-server` at 256k
  context. Ollama-style aliases route through Ollama's OpenAI-compatible `/v1`
  endpoint when configured/running.

Example local agent dispatch:

```json
{
  "name": "LocalAgent",
  "folder": "/home/user/Projects/plexorcist",
  "task": "Inspect the project, make the focused fix, validate it, and commit locally.",
  "brain": "local-agent",
  "model": "qwen3-coder-next"
}
```

With `WORKER_REPORT_TO_THREAD=true` (default), terminal worker reports are also
appended to the active Overlord conversation when the active brain supports it.
Codex app-server uses `thread/inject_items` to append a tagged
`[BRIDGE/SYSTEM WORKER REPORT]` developer-role history item without starting a
model turn, so it does not create a reply loop or extra Telegram message. This
path is durable context for future status questions; current Codex UI does not
render injected items in an already-open live UI.

With `WORKER_REPORT_VISIBLE_TURN=true` (default `false`), the bridge also starts
a real tagged Codex app-server `turn/start` after the durable append. That turn
asks Codex to produce one terse assistant status message beginning
`[BRIDGE/SYSTEM WORKER STATUS]` in the active bridge Codex app-server thread.
For that status to appear live in an already-open Codex TUI, both the bridge and
the TUI must be attached to the shared Unix socket via
`OVERLORD_CODEX_APP_SERVER_PROXY=true` and `overlord`'s
`codex --remote unix://PATH resume <thread>` path. The working path was verified
with `SocketVisibleTest` on 2026-06-25: Telegram received the worker completion
and the Codex TUI showed the visible bridge status turn. Earlier
`thread/inject_items` and bridge-private stdio `turn/start` paths were durable
transcript/history only; they did not repaint an already-open separate TUI.
If a Codex turn is already active, the bridge first interrupts it with
`turn/interrupt` and waits for it to settle before starting the status turn.
If that active turn was started by another Codex client, the bridge infers the
current unfinished `turn_id` from the shared rollout JSONL before interrupting.
During that report turn, the Codex brain declines any approval or interactive
tool request without asking Telegram, and the prompt forbids tool use, worker
dispatch, approval, recursion, or follow-up work.

### CLI-side worker-report delivery (dual delivery, brain-neutral)

Codex's `thread/inject_items`/`turn/start` paths above work because the Codex
app-server is a single persistent process that both the bridge and a terminal
TUI attach to as clients — mutating its in-memory thread state repaints any
attached live UI. Claude Code has no equivalent: each `claude` invocation is
self-contained and only reads its session transcript at start/resume, so
there is no local socket for an external process to push content into an
already-running interactive `claude` session. (Claude Code's own "Remote
Control" feature does something similar, but only for the official claude.ai
web/mobile client over a cloud-mediated channel — not something this bridge
drives, and it's disabled outright under API-key auth.)

So the `overlord` launcher and bridge build the closest real substitute out of
tmux, which does own the pty of an interactive session:

- The launcher runs the interactive brain inside a tmux session named
  `overlord-<brain>` (pane 0 = the brain). On first launch it splits off a
  second, passive pane (pane 1) that runs `tail -F` on
  `worker_reports/cli_feed.log`. Re-running `overlord` (from any terminal)
  attaches/switches to the same live session rather than starting a new one.
- With `WORKER_REPORT_CLI_FEED=true` (default), the bridge appends every
  worker completion/failure/timeout to that feed file. The kernel's inotify
  wakes the `tail -F` reader the instant it's written — genuine push, not a
  poll loop — and this channel never touches the brain pane's input, so it
  cannot corrupt anything Ben is mid-typing. This is on by default and works
  regardless of which brain is active, since it operates at the tmux/pty
  level rather than through a brain-specific API.
- With `WORKER_REPORT_TERMINAL_INJECT=true` (default `false`, opt-in), the
  bridge additionally types the report into the live brain pane as a real
  turn via `tmux send-keys`, so the brain actually reads it in-context —
  mirroring what Codex's `thread/inject_items` achieves. Because there is no
  reliable external signal for "Ben is about to type," this is guarded by
  `modules/cli_notify.py:pane_input_is_idle`, which inspects the pane's
  prompt line via `tmux capture-pane -e`: Claude Code renders its empty-input
  placeholder hint with the ANSI dim attribute, while real typed text has no
  such wrapper, so the check can tell "empty prompt" from "Ben has something
  typed" and skips injection on any doubt (including if the pane can't be
  inspected at all).
- Both channels are independent of `WORKER_REPORT_TO_THREAD`/
  `WORKER_REPORT_VISIBLE_TURN` above (which are Codex-specific today; Claude's
  `record_event`/`record_visible_event` are unimplemented and always report
  unsupported) and never take `self._brain_lock`, so they can't stall on an
  in-flight turn.

## Security

- The bot answers **only** `OWNER_CHAT_ID`; every other sender is dropped.
- Secrets stay in `.env` (chmod 600, git-ignored) — never committed.
- The shared `PermissionGate` auto-denies off-limits secrets and asks for the
  rest, for **both** brains.
- Claude adds a hard floor via `~/.claude/settings.json` deny rules. Codex gets
  the Overlord rules from this repo's `AGENTS.md`, injected as app-server
  developer instructions, plus its sandbox + approval policy. See
  [Codex brain setup](#guardrails-for-codex).
- Telegram long-polling is outbound-only; no inbound ports are exposed.

## How it behaves

- Idle until you send a task. Say *"let's work on Plexorcist"* and the Overlord
  spawns an agent scoped to `~/Projects/plexorcist`, works, reports back, done.
- One persistent conversation, so it remembers context across messages.
- Anything outside the allowlist → you get **Allow once**, **Deny**, and
  **This exact action (session)** buttons. The session grant binds the tool,
  arguments, workspace, and resolved paths; changing them asks again. Grants
  expire on `/new` or restart. `/permissions` lists grants and
  `/permissions revoke <id|all>` revokes them. Hard off-limits checks run first.
  Explicit `OVERLORD_AUTO_APPROVE` configuration remains a legacy global mode,
  labelled in `/permissions`; revoke all also disables it until restart. No answer
  within `OVERLORD_PERMISSION_TIMEOUT` (default 5 min) = auto-deny.

### Manual free OpenRouter workers

Dispatch with `brain: "openrouter"` and an exact tool-capable `model` ID ending in `:free`. Enable `OVERLORD_WORKER_OPENROUTER_ENABLED=1` and configure `OVERLORD_WORKER_OPENROUTER_API_KEY` in the bridge environment. This explicitly permits sending worker task and project context to OpenRouter providers. The bridge validates current catalog input/output prices before reading hinted files, and sends a zero-price provider ceiling with fallback disabled on every turn. Missing consent, keys, pricing, or tool support fails closed. Resume is rejected. The existing worker file/command restrictions apply. This manual pilot is not automatically routed or live-qualified; no provider calls were made during offline testing.

Provider contract: [OpenRouter provider routing](https://openrouter.ai/docs/guides/routing/provider-selection).

### Automatic per-prompt model selection

Configure a local OpenAI-compatible classifier (for example an existing Ollama server) with `OVERLORD_ROUTER_MODEL` and `OVERLORD_ROUTER_API_BASE`, then set `OVERLORD_ROUTER_ENABLED=1`. The endpoint must be loopback HTTP. `OVERLORD_ROUTER_PROFILES` is JSON keyed by `claude` and `codex`; each entry has `model`, a capability/cost `description`, and `qualified: true` only after that exact model has been validated with the provider. Unqualified entries cannot be selected. No classifier model is downloaded or started automatically.

```json
{"claude":[{"model":"sonnet","description":"Lower-cost routine implementation and explanation","qualified":false},{"model":"opus","description":"Difficult design and high-stakes judgment","qualified":false}]}
```

The classifier interprets each prompt with up to eight recent dialogue entries (6,000 characters), chooses from the active provider's qualified list, and returns a validated model ID and reason. It has no tools, does not enter the persistent native conversation, and has a 12-second deadline. Invalid selections, outages, oversized prompts, or refused native model changes retain the current model; the user prompt is sent once. Native session IDs and permission grants are retained. Codex also checks the visible native `model/list` catalog before classification, with a five-second deadline and ten-page limit. Catalog failure retains the current model. Catalog visibility is not proof of account entitlement, and operator qualification remains required. Claude catalog discovery, gas-aware cross-provider routing, and a live routing evaluation set remain open.

`/model` shows routing state and the last decision. `/model <name>` sets a manual override for this bridge process; `/model auto` restores automatic selection after configuration. Routing decisions do not overwrite the saved manual model. A live shared Claude terminal retains its own model because its transport does not expose per-turn model selection. No paid classifier calls or live qualification were performed for this increment.

`/context` can include the last native Claude context token/window snapshot when `OVERLORD_CLAUDE_CONTEXT_SNAPSHOTS=1` is explicitly configured and supported by the SDK/CLI. Collection is disabled by default: [upstream issue #1159](https://github.com/anthropics/claude-agent-sdk-python/issues/1159) reports invisible billable calls on Bedrock. Provider qualification and separate cost reconciliation are required before enabling it. Its timestamp identifies when it was observed; it is not live pressure. Unsupported or malformed readings remain unknown.

Multi-question requests show progress and require review before submitting the complete set. Use the review buttons to edit a selected answer or cancel all answers. Single-question requests retain direct submission. Cancellation or timeout during a set returns no partial answers. Invalid, duplicate, or oversized sets are rejected instead of silently dropping questions; requests support at most four questions. Pending native requests are not restored after a bridge restart.

Permission decisions are recorded locally in `run/permissions.jsonl`, with one retained `.previous` file and a 256 KiB cap per file. Records contain UTC time, owner ID, decision source and a SHA-256 action identity; they omit command arguments, paths and conversation text. `/permissions` reports audit health. A failed audit write denies approvals (including configured auto-approval and reused grants); revocation and denial still take effect if storage is unavailable. The audit remains local and is not a complete audit of shared-terminal or worker side effects.

## Free-model chat brain

`/brain free` (or `OVERLORD_BRAIN=free`) switches Telegram to plain chat over free
tiers. It is text-only: no tools, files, commands or workers, so it needs no
permission prompts. Configure `OVERLORD_FREE_MODELS` (`provider:model`, comma
separated; providers `nvidia` and `openrouter`) and use `/model` to list or switch.

Usage limits are enforced before each request: a per-provider requests-per-minute
window and optional daily cap (`OVERLORD_FREE_<PROVIDER>_RPM` / `_DAILY`, persisted
in `run/free_usage.json` so restarts cannot reset them), plus cooldowns taken from
`Retry-After` and rate-limit headers after a 429. A model that is cooling down or
out of budget is skipped for the next configured one, the reply says which model
answered, and when every model is spent you are told when the first returns.
`/status` lists keys, every model's state and each provider's budget. OpenRouter
leads the default list (`openrouter:free` discovers the best zero-priced chat models
from the live catalog at start-up) and is on once a key is set
(`OVERLORD_FREE_OPENROUTER_ENABLED=0` opts out); it only accepts `:free` IDs and
admits a model only while the live catalog prices it at zero.

**API keys window:** tray icon → *API keys…* (or `run-windows.ps1 -Setup`) opens a
window to paste and test the NVIDIA and OpenRouter keys. It saves them to `.env` and
a running Overlord reloads them without a restart.

**Start-up splash (Windows):** a small window shows the start-up stage and a live log
tail until Overlord is online, and stays up with the error if start-up fails.
`OVERLORD_SPLASH=0` disables it. Chat history is kept in
`.session.free`; `/new` clears it. Defaults are conservative published free-tier
numbers, not live-verified; no provider calls were made in offline tests.

### Free models working on projects (`/work`)

The free chat brain has no tools, so project work runs as a *worker* fed by the same
free-model pool (shared rate limits, cooldowns, discovery and fallback), from any
active brain:

- `/work` lists projects (folders under your workspace, `OVERLORD_PROJECTS_ROOT`,
  `~/Projects`, `~/Documents`); `/work <project> <task>` starts a worker in that folder;
  `/work status` and `/work stop [project]` manage it. You get a Telegram message when it
  finishes, with the models that did the work.
- The worker can list/read/write files and run commands **inside that one folder**,
  under the same denial rules as the other agent workers (no `.env`, SSH/cloud
  credentials, paths outside the folder, `sudo`, …).
- Free models are unpredictable, so **writes and commands ask you first** on Telegram
  (Allow once / Deny / allow this exact action for the session). `OVERLORD_FREE_WORK_APPROVAL`
  = `all` (default) · `commands` · `none`. Reads and listings never ask.
- When every free model is rate limited the worker waits up to
  `OVERLORD_FREE_WORK_PATIENCE` seconds (default 120) for one to return, then stops with
  the reason. `OVERLORD_FREE_WORK_STEPS` (default 30) caps tool steps.
- Workers can also be dispatched directly with `"brain": "free"`. The workspace folder
  is now an allowed worker root, so workers work where projects live (for example
  `C:\Users\you\source\repos`), not only in `~/Projects`.

Nothing here was exercised against live providers; tool-calling quality varies a lot
between free models, so review what a free worker changed (it should commit locally).
