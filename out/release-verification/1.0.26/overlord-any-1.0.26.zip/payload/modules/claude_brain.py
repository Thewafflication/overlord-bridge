"""ClaudeBrain: the Claude Agent SDK behind the :class:`Brain` interface.

This is the original Overlord logic, moved verbatim in behavior:

  * ``ClaudeSDKClient`` with the ``claude_code`` system-prompt preset and
    ``setting_sources=[user, project, local]`` so ~/.claude/CLAUDE.md +
    settings.json (the strict-allowlist deny rules) load as a hard floor.
  * ``can_use_tool`` routes each tool call through the shared
    :class:`PermissionGate` (off-limits pre-screen + Telegram permission
    choices + timeout -> deny).
  * Session persistence via a ``.session`` file passed as ``resume=`` on
    startup, with a stale-session fallback. ``reset`` wipes it.

Session hand-off (2026-07-11): Claude Code will not let two live processes
hold the same session id — a second ``--resume`` on an id another live
process already holds gets silently forked onto a new id instead of resuming
in place (verified empirically; see SHARED_BRAIN_TASK.md). Keeping a
long-lived ``ClaudeSDKClient`` connected across Telegram turns therefore
permanently squats the pinned session and forks Ben's terminal every time he
runs ``overlord``. So this brain holds NO client between turns: ``query()``
connects fresh (re-reading the pin, so it picks up whatever session the CLI
most recently left the pin pointing at), then disconnects in a ``finally``
right after the turn, freeing the session for the CLI (or the next Telegram
turn) to resume in place. Verified: disconnecting a client fully releases
the underlying ``claude`` subprocess, and a subsequent resume of that id from
a fresh process lands on the same id with no fork.
"""

from __future__ import annotations

import asyncio
import dataclasses
import datetime
import json
import logging
import os
from pathlib import Path
from typing import Any, AsyncIterator

import aiohttp
from claude_agent_sdk import (
    AssistantMessage,
    ClaudeAgentOptions,
    ClaudeSDKClient,
    HookMatcher,
    PermissionResultAllow,
    PermissionResultDeny,
    ResultMessage,
    SystemMessage,
    TextBlock,
    ToolPermissionContext,
)

from modules import shared_job
from modules.host_context import host_instructions
from modules.output_text import OUTPUT_INSTRUCTIONS
from modules.brain import Brain, PermissionGate, collect_candidates
from modules.command_activity import log_command
from modules.commands import reset_has_passed
from modules.token_meter import estimate_tokens

log = logging.getLogger("overlord.claude")

CLAUDE_USAGE_CACHE = Path.home() / ".cache" / "near-limit-handoff" / "usage.json"
CLAUDE_CREDENTIALS = Path.home() / ".claude" / ".credentials.json"
CLAUDE_USAGE_API = "https://api.anthropic.com/api/oauth/usage"
CLAUDE_COUNT_TOKENS_API = "https://api.anthropic.com/v1/messages/count_tokens"

# Effort levels the Agent SDK accepts (``--effort`` on the CLI).
EFFORT_LEVELS = ("low", "medium", "high", "xhigh", "max")

# ``/quote`` needs a concrete model id; the bridge is normally configured with a
# CLI alias ("opus", "sonnet"). Map the aliases we know to a countable id, and
# let OVERLORD_COUNT_TOKENS_MODEL override when a newer id ships. A wrong guess
# is not fatal: the count falls back to the local estimator.
COUNT_TOKENS_ALIASES = {
    "opus": "claude-opus-4-1-20250805",
    "sonnet": "claude-sonnet-4-5-20250929",
    "haiku": "claude-haiku-4-5-20251001",
}


def _countable_model(*candidates: str) -> str:
    """Pick a concrete model id for ``count_tokens`` from what we know.

    Preference order: an explicit override, then any candidate that is already
    a full id (after one turn the SDK tells us exactly which model answered),
    then a mapped alias. Guessing wrong is survivable — the caller falls back
    to the local estimator — so this never raises.
    """
    override = os.environ.get("OVERLORD_COUNT_TOKENS_MODEL", "").strip()
    if override:
        return override
    names = [str(name or "").strip() for name in candidates]
    for name in names:
        if name.startswith("claude-"):
            return name
    for name in names:
        mapped = COUNT_TOKENS_ALIASES.get(name.lower())
        if mapped:
            return mapped
    return COUNT_TOKENS_ALIASES["sonnet"]


def _accumulate(running: dict[str, int], usage: dict[str, Any]) -> None:
    """Add one API call's counters into a running per-turn tally."""
    for key, value in usage.items():
        if isinstance(value, int) and value >= 0:
            running[key] = running.get(key, 0) + value


async def _claude_access_token() -> str | None:
    """Read the Claude Code OAuth access token, if the CLI has one on disk."""
    try:
        credentials = json.loads(CLAUDE_CREDENTIALS.read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError):
        return None
    token = (credentials.get("claudeAiOauth") or {}).get("accessToken")
    return token if isinstance(token, str) and token else None

# Tool-input keys that carry a filesystem path.
PATH_KEYS = ("file_path", "path", "notebook_path", "directory")

# Prepended to every Telegram turn injected into the shared job, so the brain can
# tell a phone message from Ben typing at the keyboard -- a distinction injection
# would otherwise erase, since an injected turn is just an ordinary turn.
#
# Provenance ONLY. Ben, 2026-07-13: "you can be the same in telegram, just it may
# help to know the source of the message." So this must NOT instruct the brain to
# behave differently (shorter, terser, etc) -- same Nova on both mics. It only says
# where the message came in from, which is occasionally load-bearing: he can't see
# a rendered diff or click a file path on a phone, and he may not be at the desk.
TELEGRAM_TAG = "📱 [via Telegram]\n\n"
EDIT_TOOLS = {"Edit", "MultiEdit", "Write", "NotebookEdit"}


# Set when the last live usage call was rejected because the CLI login expired.
usage_auth_expired = False


def _claude_usage_window(data: Any) -> dict[str, Any] | None:
    if not isinstance(data, dict) or data.get("utilization") is None:
        return None
    try:
        used = round(float(data["utilization"]), 1)
    except (TypeError, ValueError):
        return None
    # A window whose reset time is behind us has rolled over, whatever the
    # (possibly weeks-old) cached percentage says.
    passed = reset_has_passed(data.get("resets_at"))
    if passed:
        used = 0.0
    return {
        "used": used,
        "gas": max(0, round(100 - used, 1)),
        "resets_at": data.get("resets_at"),
        "reset_passed": passed,
    }


def _normalize_claude_usage(data: Any) -> dict[str, Any] | None:
    if not isinstance(data, dict):
        return None
    session = _claude_usage_window(data.get("five_hour"))
    weekly = _claude_usage_window(data.get("seven_day"))
    if session is None and weekly is None:
        return None
    return {
        "session": session,
        "weekly": weekly,
        "plan_type": None,
        "source": "anthropic_usage",
    }


async def _claude_usage_payload(max_cache_age: int = 120) -> tuple[dict[str, Any] | None, bool]:
    """Return Claude cap data and whether it came from a stale cache."""
    global usage_auth_expired
    cached: dict[str, Any] | None = None
    try:
        raw = json.loads(CLAUDE_USAGE_CACHE.read_text(encoding="utf-8"))
        if isinstance(raw, dict):
            cached = raw
            age = datetime.datetime.now().timestamp() - CLAUDE_USAGE_CACHE.stat().st_mtime
            if age < max_cache_age:
                return cached, False
    except (OSError, ValueError, TypeError):
        pass

    try:
        credentials = json.loads(CLAUDE_CREDENTIALS.read_text(encoding="utf-8"))
        token = (credentials.get("claudeAiOauth") or {}).get("accessToken")
        if not token:
            return cached, cached is not None
        timeout = aiohttp.ClientTimeout(total=6)
        headers = {
            "Authorization": f"Bearer {token}",
            "anthropic-beta": "oauth-2025-04-20",
        }
        async with aiohttp.ClientSession(timeout=timeout, headers=headers) as session:
            async with session.get(CLAUDE_USAGE_API) as response:
                if response.status != 200:
                    usage_auth_expired = response.status == 401
                    return cached, cached is not None
                usage_auth_expired = False
                data = await response.json()
        if not isinstance(data, dict):
            return cached, cached is not None
        try:
            CLAUDE_USAGE_CACHE.parent.mkdir(parents=True, exist_ok=True)
            CLAUDE_USAGE_CACHE.write_text(json.dumps(data), encoding="utf-8")
        except OSError:
            pass
        return data, False
    except (OSError, ValueError, TypeError, aiohttp.ClientError, asyncio.TimeoutError):
        return cached, cached is not None


class ClaudeBrain(Brain):
    name = "claude"
    supports_effort = True

    def __init__(
        self,
        *,
        gate: PermissionGate,
        cwd: str,
        model: str,
        session_file: Path,
        developer_instructions: str = "",
        auto_approve_edits: bool = False,
        effort: str | None = None,
    ) -> None:
        self.gate = gate
        self.cwd = cwd
        self.model = model
        self._active_model = model
        self.session_file = session_file
        self.developer_instructions = developer_instructions.strip()
        self.auto_approve_edits = auto_approve_edits
        self.effort = (effort or "").strip().lower() or None
        self._session_id: str | None = None
        self.last_turn_usage: dict[str, Any] | None = None
        self.last_turn_cost_usd: float | None = None
        self.last_turn_outcome: str = "ok"
        self._available_commands: set[str] | None = None
        self._compaction_active = False
        self.compaction_status = "idle"

    @property
    def session_id(self) -> str | None:
        return self._session_id

    # ---------------------------------------------------------------- permission
    @staticmethod
    def _format_detail(
        tool_name: str, tool_input: dict[str, Any], context: ToolPermissionContext
    ) -> str:
        detail = ""
        if tool_name == "Bash" and isinstance(tool_input.get("command"), str):
            detail = tool_input["command"]
        else:
            for key in PATH_KEYS:
                if isinstance(tool_input.get(key), str):
                    detail = tool_input[key]
                    break
        title = getattr(context, "title", None) or getattr(context, "display_name", None)
        if title:
            detail = f"{title}\n\n{detail}" if detail else title
        return detail

    async def can_use_tool(
        self, tool_name: str, tool_input: dict[str, Any], context: ToolPermissionContext
    ) -> PermissionResultAllow | PermissionResultDeny:
        if self._compaction_active:
            return PermissionResultDeny(message="Tool actions are disabled during compaction.")
        if tool_name == "AskUserQuestion":
            return await self._answer_user_questions(tool_input)
        candidates = collect_candidates(tool_input, PATH_KEYS)
        if self.auto_approve_edits and self._is_safe_workspace_edit(
            tool_name, candidates
        ):
            log.info("Auto-approved %s inside workspace", tool_name)
            return PermissionResultAllow()
        detail = self._format_detail(tool_name, tool_input, context)
        allow = await self.gate.request(
            tool_name, detail, candidates,
            context={
                "workspace": str(Path(self.cwd).resolve()), "input": tool_input,
                "paths": [
                    tool_input[key] for key in PATH_KEYS
                    if isinstance(tool_input.get(key), str)
                ],
            },
        )
        if allow:
            return PermissionResultAllow()
        return PermissionResultDeny(message="Denied by operator via Telegram.")

    async def _answer_user_questions(
        self, tool_input: dict[str, Any]
    ) -> PermissionResultAllow | PermissionResultDeny:
        questions = tool_input.get("questions")
        if not isinstance(questions, list) or not questions:
            return PermissionResultDeny(message="No valid question was provided.")
        if len(questions) > 4:
            return PermissionResultDeny(message="Split requests into at most four questions.")
        keys = [q.get("question") if isinstance(q, dict) else None for q in questions]
        if (any(not isinstance(key, str) or not key.strip() for key in keys)
                or len({key.strip() for key in keys}) != len(keys)):
            return PermissionResultDeny(message="Every question must have unique, nonempty text.")
        answers: dict[str, str] = {}
        review = []
        for index, item in enumerate(questions):
            if not isinstance(item, dict):
                continue
            question = str(item.get("question") or "").strip()
            if not question:
                continue
            if question in answers:
                return PermissionResultDeny(message="Question text must be unique within a set.")
            header = str(item.get("header") or "Question").strip()
            options = []
            for option in item.get("options") or []:
                if not isinstance(option, dict):
                    continue
                label = str(option.get("label") or "").strip()
                if label:
                    options.append(
                        (label, str(option.get("description") or "").strip())
                    )
            prompt = f"❓ {header}\n\n{question}"
            if len(questions) > 1:
                prompt = f"Question {index + 1} of {len(questions)}\n\n" + prompt
            if item.get("multiSelect"):
                prompt += (
                    "\n\nYou may reply with multiple choices separated by commas."
                )
            answer = await self.gate.choose(prompt, options[:8])
            if answer is None:
                return PermissionResultDeny(
                    message="The operator did not answer the Telegram question."
                )
            answers[question] = answer
            review.append({"key": question, "prompt": prompt, "options": options[:8]})
        if not answers:
            return PermissionResultDeny(message="No valid question was provided.")
        if len(review) > 1:
            reviewed = await self.gate.review_answers(review, answers)
            if reviewed is None:
                return PermissionResultDeny(message="The operator did not submit the complete answer set.")
            answers = reviewed
        return PermissionResultAllow(
            updated_input={**tool_input, "answers": answers}
        )

    def _is_safe_workspace_edit(self, tool_name: str, candidates: list[str]) -> bool:
        if tool_name not in EDIT_TOOLS or not candidates:
            return False
        if self.gate.offlimits_match(candidates) is not None:
            return False
        workspace = Path(self.cwd).resolve()
        for candidate in candidates:
            path = Path(candidate).expanduser()
            resolved = (workspace / path).resolve() if not path.is_absolute() else path.resolve()
            if self.gate.offlimits_match([str(resolved)]) is not None:
                return False
            if not resolved.is_relative_to(workspace):
                return False
        return True

    # ---------------------------------------------------------------- session
    def _load_session(self) -> str | None:
        try:
            sid = self.session_file.read_text().strip()
            return sid or None
        except FileNotFoundError:
            return None

    def _save_session(self, session_id: str) -> None:
        # Persist the latest id each turn (a resumed conversation may be assigned
        # a new id), so the next restart picks up where we left off.
        if session_id and session_id != self._session_id:
            self._session_id = session_id
            try:
                self.session_file.write_text(session_id)
            except OSError as exc:
                log.error("Could not persist session id: %s", exc)

    def _effort_option(self) -> dict[str, Any]:
        """``{"effort": ...}`` when the installed SDK understands it, else ``{}``.

        ``effort`` is a recent ClaudeAgentOptions field. Probing the dataclass
        keeps an older SDK working (the setting is ignored, and /effort says so)
        instead of failing every turn with a TypeError.
        """
        if not self.effort:
            return {}
        try:
            supported = {f.name for f in dataclasses.fields(ClaudeAgentOptions)}
        except TypeError:  # pragma: no cover - not a dataclass in some future SDK
            return {"effort": self.effort}
        if "effort" not in supported:
            log.warning(
                "The installed Claude Agent SDK has no 'effort' option; "
                "ignoring effort=%s.",
                self.effort,
            )
            return {}
        return {"effort": self.effort}

    async def _log_shell_hook(self, data, tool_use_id, context) -> dict:
        if data.get("tool_name") == "Bash":
            phase = {"PreToolUse": "requested", "PostToolUse": "completed",
                     "PostToolUseFailure": "failed"}.get(data.get("hook_event_name"), "requested")
            log_command("claude", phase, data.get("tool_input", {}).get("command", ""),
                        data.get("cwd", self.cwd))
        return {}

    def _build_options(self, resume: str | None) -> ClaudeAgentOptions:
        return ClaudeAgentOptions(
            cwd=self.cwd,
            model=self.model,
            system_prompt={
                "type": "preset",
                "preset": "claude_code",
                "append": self.developer_instructions,
            },
            setting_sources=["user", "project", "local"],
            permission_mode="default",
            can_use_tool=self.can_use_tool,
            hooks={event: [HookMatcher(matcher="Bash", hooks=[self._log_shell_hook])]
                   for event in ("PreToolUse", "PostToolUse", "PostToolUseFailure")},
            resume=resume,
            **self._effort_option(),
        )

    async def _open(self, resume: str | None) -> ClaudeSDKClient:
        """Connect a fresh client for a single turn (see module docstring)."""
        client = ClaudeSDKClient(options=self._build_options(resume))
        try:
            await client.connect()
            return client
        except Exception as exc:
            if resume is None:
                raise
            # Stale/invalid saved session -> start fresh. The pin is dropped only
            # once the fresh client is up: if the CLI itself is down or missing,
            # the failure was not the session's fault and the pin must survive.
            log.warning("Resume of %s failed (%s); starting fresh.", resume, exc)
            client = ClaudeSDKClient(options=self._build_options(None))
            await client.connect()
            self._session_id = None
            self.session_file.unlink(missing_ok=True)
            return client

    # ---------------------------------------------------------------- lifecycle
    async def connect(self, resume: str | None = None) -> None:
        # No live client is held between turns (see module docstring), so this
        # just seeds which session the first query() will resume. Honor an
        # explicit resume id; otherwise pick up the persisted pin.
        sid = resume if resume is not None else self._load_session()
        self._session_id = sid
        log.info(
            "ClaudeBrain ready (cwd=%s, model=%s, resumed=%s); "
            "sessions open per turn, not held",
            self.cwd,
            self.model,
            sid is not None,
        )

    async def reset(self) -> None:
        self.context_snapshot = None
        self.session_file.unlink(missing_ok=True)
        self._session_id = None
        self.compaction_status = "idle"
        log.info("Claude session reset via /new")

    async def disconnect(self) -> None:
        # Nothing to tear down: no client is held outside an active turn.
        return

    async def compact(self, *, timeout: float = 120) -> str | None:
        """Discover /compact and require its compact_boundary completion evidence."""
        self.last_turn_usage = None
        self.last_turn_cost_usd = None
        self.last_turn_outcome = "ok"
        self.context_snapshot = None
        if not self._session_id:
            return "No Claude conversation is loaded."
        job = await asyncio.to_thread(shared_job.live_job, self.session_file)
        if job is not None:
            return "Claude's live shared terminal owns this session; SDK compaction cannot attach."
        client = await self._open(self._session_id)
        boundary = False
        successful_result = False
        try:
            info = await client.get_server_info()
            commands = (info or {}).get("commands")
            if isinstance(commands, list):
                available = {
                    item.get("name") if isinstance(item, dict) else item
                    for item in commands
                    if isinstance(item, (str, dict))
                }
            else:
                available = self._available_commands or set()
            if "compact" not in available:
                return "This Claude session does not advertise a compact command."
            self._compaction_active = True
            self.compaction_status = "running"
            async with asyncio.timeout(timeout):
                await client.query("/compact")
                async for message in client.receive_response():
                    if isinstance(message, SystemMessage) and message.subtype == "compact_boundary":
                        boundary = True
                    if isinstance(message, ResultMessage):
                        successful_result = (
                            not message.is_error and message.subtype == "success"
                        )
                        self.last_turn_usage = message.usage
                        self.last_turn_cost_usd = message.total_cost_usd
                        self._save_session(message.session_id)
            if not boundary or not successful_result:
                self.compaction_status = "failed"
                self.last_turn_outcome = "error"
                return "Claude did not confirm a successful compaction boundary."
            self.compaction_status = "completed"
            return None
        except asyncio.TimeoutError:
            self.compaction_status = "uncertain"
            self.last_turn_outcome = "error"
            return "Claude compaction timed out; completion is unknown."
        except asyncio.CancelledError:
            self.compaction_status = "uncertain"
            self.last_turn_outcome = "error"
            raise
        except Exception as exc:
            self.compaction_status = "failed"
            self.last_turn_outcome = "error"
            return f"Claude compaction failed: {exc}"
        finally:
            self._compaction_active = False
            try:
                await client.disconnect()
            except Exception as exc:
                log.warning("Compaction client cleanup failed: %s", exc)

    async def status(self, *, force_refresh: bool = False) -> dict[str, Any]:
        payload, stale = await _claude_usage_payload(
            max_cache_age=0 if force_refresh else 120
        )
        usage = _normalize_claude_usage(payload)
        note = "Usage is from the last cached update." if stale else None
        if usage_auth_expired:
            note = (
                "Claude login expired, so live usage is unavailable; run `claude` "
                "once to refresh it. Showing the last cached reading."
            )
        return {
            "brain": self.name,
            "model": self._active_model or self.model,
            "effort": self.effort,
            "session_id": self.session_id,
            "usage": usage,
            "usage_note": note,
        }

    # ------------------------------------------------------------- runtime knobs
    async def set_model(self, model: str) -> str | None:
        """Point subsequent turns at *model*.

        No client is held between turns (see the module docstring), so this only
        has to update the field the next ``_build_options`` reads — the change
        lands on the next message with no reconnect and no session churn.
        """
        name = (model or "").strip()
        if not name:
            return "Give a model name, e.g. /model sonnet"
        if name != self.model:
            self.context_snapshot = None
        self.model = name
        self._active_model = name
        return None

    async def set_effort(self, effort: str) -> str | None:
        level = (effort or "").strip().lower()
        if level in ("", "default", "auto", "off", "none"):
            self.effort = None
            return None
        if level not in EFFORT_LEVELS:
            return f"Unknown effort {level!r}. Choose: {', '.join(EFFORT_LEVELS)}"
        self.effort = level
        if not self._effort_option():
            self.effort = None
            return (
                "The installed Claude Agent SDK has no reasoning-effort option; "
                "nothing was changed."
            )
        return None

    async def model_options(self) -> list[tuple[str, str]]:
        options = [("opus", "most capable"), ("sonnet", "balanced"), ("haiku", "fastest, lightest")]
        if self.model and self.model not in {name for name, _ in options}:
            options.append((self.model, "configured"))
        return options

    async def effort_options(self) -> list[tuple[str, str]]:
        notes = {"low": "fastest", "max": "deepest reasoning"}
        return [("default", "engine default")] + [(l, notes.get(l, "")) for l in EFFORT_LEVELS]

    async def count_input_tokens(self, text: str) -> tuple[int | None, str]:
        """Ask Anthropic exactly what *text* costs as input; estimate if it can't.

        ``count_tokens`` is free and does not touch the conversation, so a quote
        never consumes a turn or perturbs the pinned session.
        """
        if not text.strip():
            return 0, "exact"
        token = await _claude_access_token()
        if token:
            try:
                timeout = aiohttp.ClientTimeout(total=8)
                headers = {
                    "Authorization": f"Bearer {token}",
                    "anthropic-version": "2023-06-01",
                    "anthropic-beta": "oauth-2025-04-20",
                    "content-type": "application/json",
                }
                body = {
                    "model": _countable_model(self._active_model, self.model),
                    "messages": [{"role": "user", "content": text}],
                }
                async with aiohttp.ClientSession(
                    timeout=timeout, headers=headers
                ) as session:
                    async with session.post(
                        CLAUDE_COUNT_TOKENS_API, json=body
                    ) as response:
                        if response.status == 200:
                            data = await response.json()
                            count = data.get("input_tokens")
                            if isinstance(count, int):
                                return count, "exact"
                        else:
                            log.debug(
                                "count_tokens returned HTTP %s; estimating instead",
                                response.status,
                            )
            except (
                aiohttp.ClientError,
                asyncio.TimeoutError,
                ValueError,
                TypeError,
            ) as exc:
                log.debug("count_tokens call failed (%s); estimating instead", exc)
        return estimate_tokens(text), "estimate"

    async def _watch_and_push(
        self,
        job: "shared_job.SharedJob",
        message: str,
        *,
        timeout_s: float = 1800.0,
        poll_s: float = 2.0,
    ) -> None:
        """Poll the shared job's transcript and push the COMPLETE reply to Ben on
        Telegram once the turn actually finishes.

        Turn completion is read from the transcript itself -- an assistant record
        with stop_reason 'end_turn', or a following human turn (see
        ``shared_job.poll_reply_status``) -- NOT from the reply text pausing. A
        reply that opens with one line, runs tool calls for a minute, then answers
        looks "paused" the whole time the tools run; the old stability heuristic
        mistook that pause for the end and pushed only the opening line,
        black-holing everything after it. Runs detached on the bridge loop so it
        outlives the turn that spawned it.
        """
        import time as _time

        deadline = _time.monotonic() + timeout_s
        last: str | None = None
        prev: str | None = None
        try:
            while _time.monotonic() < deadline:
                await asyncio.sleep(poll_s)
                reply, done = await asyncio.to_thread(
                    shared_job.poll_reply_status, job, message
                )
                if reply:
                    last = reply
                # Push only when the turn has ENDED and the reply text is the same
                # as the previous poll. end-of-turn can be stamped on the final
                # message's thinking record a beat before its visible-text record
                # is flushed; one stable poll guarantees we send the whole answer,
                # never a half-flushed one. A mid-turn tool pause never satisfies
                # `done`, so it can't trigger an early push.
                if done and reply and reply == prev:
                    self.gate.telegram.send(self.gate.owner, reply)
                    return
                prev = reply
            log.warning(
                "Async reply watcher for shared job %s gave up after %.0fs.",
                job.job_id, timeout_s,
            )
            if last:
                # Never closed cleanly but we have text: send it rather than
                # leaving Ben with only the ack.
                self.gate.telegram.send(self.gate.owner, last)
        except Exception as exc:  # noqa: BLE001 - a watcher must never crash the loop
            log.error("Async reply watcher for %s failed: %s", job.job_id, exc)

    async def _capture_context(self, client) -> None:
        """Read native context control data; never infer pressure from billing."""
        self.context_snapshot = None
        # Upstream #1159 reports hidden provider spend for this control on
        # Bedrock. Do not enable collection implicitly or call it free.
        if os.environ.get("OVERLORD_CLAUDE_CONTEXT_SNAPSHOTS") != "1":
            return
        try:
            async with asyncio.timeout(2):
                data = await client.get_context_usage()
            used, maximum = data.get("totalTokens"), data.get("maxTokens")
            if (type(used) is not int or type(maximum) is not int
                    or used < 0 or maximum <= 0):
                return
            self.context_snapshot = {
                "used": used, "maximum": maximum,
                "percentage": used / maximum * 100,
                "session_id": self.session_id, "model": self.model,
                "observed_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            }
        except asyncio.CancelledError:
            raise
        except Exception:
            # Older SDKs/CLI builds do not support this control request.
            pass

    async def query(self, text: str) -> AsyncIterator[str]:
        # Near-cap reset contract with ~/.claude/hooks/near-limit-handoff.sh: the
        # hook cannot just delete the pin itself, because query() re-pins on every
        # ResultMessage (see module docstring / lines below), which would silently
        # overwrite a hook-side delete seconds later. So the hook drops a flag and
        # the bridge honors it here, at the very start of the turn. Consumed
        # (unlinked) first and unconditionally, so a skip below can never leave it
        # around to retry forever.
        # Per-turn accounting starts clean: a turn that reports nothing (the
        # shared-job path below) must not leave the previous turn's numbers
        # sitting there for the bridge to re-record as if they were new.
        self.last_turn_usage = None
        self.last_turn_cost_usd = None
        self.last_turn_outcome = "ok"
        self.context_snapshot = None

        reset_flag = self.session_file.parent / f".reset-requested{self.session_file.suffix}"
        reset_requested = reset_flag.exists()
        if reset_requested:
            reset_flag.unlink(missing_ok=True)

        # One brain, two mics: if Ben's terminal is running `overlord --shared`,
        # his session is a live Claude Code background job that a second client
        # can attach to. Type this Telegram turn straight into THAT job, so it
        # lands in the same conversation he sees in his terminal — rather than
        # opening our own SDK process on the same session. Falls back to the
        # ordinary per-turn SDK path (Design B) whenever no live shared job
        # exists, so the plain `overlord` flow is untouched. Resolved once here
        # and reused below, rather than calling live_job twice per turn.
        job = await asyncio.to_thread(shared_job.live_job, self.session_file)

        if reset_requested:
            if job is not None:
                # Claude Code refuses to resume a session a background --bg job
                # holds. If we reset here, the pin would flip to a brand-new id
                # while Ben's terminal is still sitting on the old one -- silently
                # detaching Telegram from the session he's actually looking at,
                # with no way back. Skip the reset; the flag is already consumed
                # above so this does not retry forever.
                log.warning(
                    "Reset requested near usage cap but shared job %s is live; "
                    "skipping reset so Telegram isn't detached from Ben's session.",
                    job.job_id,
                )
            else:
                await self.reset()
                log.info("Reset requested near usage cap; starting a fresh session.")

        if job is not None:
            log.info("Injecting Telegram turn into shared job %s", job.job_id)
            # Stamp the provenance. Injection lands a Telegram message as an
            # ordinary turn, indistinguishable from Ben typing at the keyboard, so
            # the brain loses a signal that used to be implicit in "this arrived
            # over the bridge". Ben offered to type a tag himself; he shouldn't
            # have to -- the bridge already knows which mic it came from.
            tagged = TELEGRAM_TAG + host_instructions() + "\n\n" + OUTPUT_INSTRUCTIONS + "\n\nOwner message:\n" + text
            reply = await asyncio.to_thread(shared_job.inject, job, tagged)
            if isinstance(reply, str) and reply:
                # Idle session answered inside the sync window: inline, as before.
                if job.session_id:
                    self._save_session(job.session_id)
                yield reply
                return
            if reply is shared_job.DELIVERED_PENDING:
                # Delivered into the live session but no reply yet (queued behind
                # the current turn, or the turn is long). Ack now and push the real
                # reply when it lands -- NEVER make Ben resend a message that
                # actually arrived. This is the core of today's fix.
                if job.session_id:
                    self._save_session(job.session_id)
                asyncio.create_task(self._watch_and_push(job, tagged))
                yield (
                    "✅ Delivered into the live terminal session. It's mid-turn, so "
                    "I'll send the reply here the moment it finishes — no need to resend."
                )
                return
            # reply is None: genuinely not delivered. Do NOT fall through to the
            # SDK path -- Claude Code REFUSES to resume a session a background job
            # holds, and `_open`'s stale-session handler would read that as a dead
            # pin, DELETE it, and start a brand-new conversation, silently
            # detaching Telegram from the session Ben is sitting in. Report it; a
            # wiped pin is not recoverable, this is.
            log.warning("Shared job %s did not accept the message; not risking the pin.", job.job_id)
            yield (
                "⚠️ Couldn't hand that to the terminal session just now — the input "
                "line had text typed at the keyboard, or the session didn't render. "
                "Nothing was sent; try again in a moment."
            )
            return

        # Always resume from the freshest pin — this is what lets a terminal
        # CLI turn (which re-pins on exit) be picked up here, and vice versa.
        sid = self._load_session()
        self._session_id = sid
        client = await self._open(sid)
        # Running tally across this turn's API calls. A turn that is stopped or
        # steered never reaches its ResultMessage, so without this the tokens it
        # genuinely spent would vanish from the ledger. The ResultMessage, when
        # it arrives, is authoritative and replaces the tally outright.
        partial: dict[str, int] = {}
        authoritative = False
        try:
            await client.query(text)
            sent_text = False
            async for msg in client.receive_response():
                if isinstance(msg, SystemMessage):
                    if msg.subtype == "init":
                        commands = msg.data.get("slash_commands")
                        if isinstance(commands, list):
                            self._available_commands = {
                                name for name in commands if isinstance(name, str)
                            }
                    elif msg.subtype == "compact_boundary":
                        self.compaction_status = "completed"
                if isinstance(msg, AssistantMessage):
                    if msg.model:
                        self._active_model = msg.model
                    if isinstance(getattr(msg, "usage", None), dict):
                        _accumulate(partial, msg.usage)
                    for block in msg.content:
                        if isinstance(block, TextBlock) and block.text.strip():
                            sent_text = True
                            yield block.text
                elif isinstance(msg, ResultMessage):
                    if msg.session_id:
                        self._save_session(msg.session_id)
                    if isinstance(msg.usage, dict):
                        self.last_turn_usage = dict(msg.usage)
                        self.last_turn_cost_usd = msg.total_cost_usd
                        authoritative = True
                    if msg.is_error:
                        # A usage cap lands here, not as an exception: the turn
                        # completed with an error result, and the tokens it did
                        # spend are reported normally.
                        self.last_turn_outcome = "error"
                        yield f"⚠️ {msg.result or 'The Overlord hit an error.'}"
                    elif not sent_text and msg.result:
                        yield msg.result
            if authoritative and self.last_turn_outcome == "ok":
                await self._capture_context(client)
        finally:
            # Runs on success, on failure, and on the CancelledError that /stop
            # and /steer raise, so an interrupted turn is still accounted for.
            if not authoritative and partial:
                self.last_turn_usage = dict(partial)
            try:
                await client.disconnect()
            except Exception as exc:
                log.error("Error disconnecting after turn: %s", exc)
